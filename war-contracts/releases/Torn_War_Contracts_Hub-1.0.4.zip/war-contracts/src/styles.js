function warContractsStyles(){return `
.wch-root{font:14px system-ui}.wch-root .tsui-body{grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto auto}
.wch-root .tsui-nav{grid-row:auto;flex-direction:row;flex-wrap:wrap;border-right:0;border-bottom:1px solid var(--tsui-border);gap:4px}.wch-root .tsui-nav button{flex:1;min-height:44px}
.wch-root .tsui-content{grid-column:1;overflow:auto;padding:20px}.wch-root .tsui-settings,.wch-root .tsui-inspector{display:none}
.wch-root .wch-page{display:flex;flex-direction:column;gap:16px;min-width:0;max-width:900px;margin:auto}.wch-root .wch-page p{margin:0;line-height:1.5}.wch-root .wch-page h2{font-size:20px;margin:0}.wch-root .wch-page h3{font-size:16px;margin:0}
.wch-root .wch-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.wch-root .wch-row>*{min-width:0}.wch-root .wch-field{display:flex;flex-direction:column;gap:7px;font-size:13px;min-width:0}
.wch-root input,.wch-root select,.wch-root textarea{max-width:100%;width:100%;min-height:44px;border:1px solid var(--tsui-border);border-radius:5px;padding:10px;background:var(--tsui-input,var(--tsui-surface));color:var(--tsui-text);box-sizing:border-box;font:inherit}
.wch-root textarea{resize:vertical;min-height:110px}.wch-root input[type=checkbox]{width:20px;min-height:20px;accent-color:var(--tsui-accent);flex:none}.wch-root .wch-check{flex-direction:row;align-items:flex-start;line-height:1.5}
.wch-root .wch-note{padding:12px 14px;background:var(--tsui-raised);border:1px solid var(--tsui-border);border-radius:6px;line-height:1.5}.wch-root .wch-muted{font-size:12px;color:var(--tsui-muted)}
.wch-root .wch-match,.wch-root .wch-contract{padding:16px;border:1px solid var(--tsui-border);border-radius:7px;display:flex;flex-direction:column;gap:9px;background:var(--tsui-surface);overflow-wrap:anywhere}
.wch-root .wch-metrics{display:flex;gap:22px;flex-wrap:wrap}.wch-root .wch-metric strong{display:block;font:600 24px Consolas,monospace;color:var(--tsui-accent)}.wch-root .wch-metric span{font-size:12px;color:var(--tsui-muted)}
.wch-root .wch-tag{font-size:11px;font-weight:600;padding:4px 7px;border:1px solid var(--tsui-border);border-radius:4px}.wch-root .wch-contract a,.wch-root .wch-match a{color:var(--tsui-accent)}
.wch-root .wch-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.wch-root .wch-list{display:flex;flex-direction:column;gap:12px}.wch-root .wch-form{display:flex;flex-direction:column;gap:14px}
.wch-root .wch-summary{white-space:pre-wrap;line-height:1.65;overflow-wrap:anywhere}.wch-root .wch-status{padding:10px 16px;margin:0;border-top:1px solid var(--tsui-border);background:var(--tsui-surface);font-size:12px;line-height:1.5;overflow-wrap:anywhere}
.wch-root [data-error=true]{color:var(--tsui-error)}.wch-root [hidden]{display:none!important}.wch-root button{min-height:44px;cursor:pointer}.wch-root button:disabled{cursor:default;opacity:.55}.wch-root :focus-visible{outline:2px solid var(--tsui-focus);outline-offset:2px}
@media(max-width:600px){.wch-root .tsui-content{padding:14px}.wch-root .wch-grid{grid-template-columns:1fr}.wch-root input,.wch-root select,.wch-root textarea{font-size:16px}.wch-root .wch-match,.wch-root .wch-contract{padding:13px}.wch-root .wch-metrics{gap:16px}}
`;}
